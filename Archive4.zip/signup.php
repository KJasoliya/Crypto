<?php include'header.php'; ?>
<?php include_once'config.php'; ?>
<?php
      if (($_SERVER['REQUEST_METHOD'] === 'POST')) {
            $userName = htmlspecialchars($_POST["userName"]);
            $userPassword = $_POST["pass_confirmation"];
			$target_dir = "uploads/";
			$target_file = $target_dir . "$userName-". basename($_FILES["fileToUpload"]["name"]);
			$userEmail=$_POST["userEmailid"];
			$qry = mysqli_query($con,"SELECT email FROM userinfo WHERE email = '$userEmail';");
            $check = mysqli_fetch_assoc($qry);
            if (!($userEmail == $check["email"])) {
				
                //passing the current date and time as a hidden parameter
				if(move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],$target_file	))
				{
					$sql = mysqli_query($con,"INSERT INTO userinfo(`id`,`name`, `email`, `password`,`datecreated`,`profilepic`) 
					VALUES ('','$userName','$userEmail','$userPassword',NOW(),'$target_file')");
				}
				else
				{
					$sql = mysqli_query($con,"INSERT INTO userinfo(`id`,`name`, `email`, `password`,`datecreated`) 
					VALUES ('','$userName','$userEmail','$userPassword',NOW()	)");
				}
                $qry = mysqli_query($sql);
                mysql_close();
                $_SESSION['userEmail'] = $userEmail;
                $_SESSION['SuccessfullLogin'] = true;
                setcookie("lastloginday", date("Y-m-d"), time() + (86400 * 30), "/");
                header("Location: ciphers.php");
            }
            mysqli_close($con);
      }

?>
<form action="" method="post"  enctype="multipart/form-data" style="padding : 0em 5em 0em 5em;"> 
      <p>
            <b>Name</b>
            <input type=text name="userName" placeholder="3-12 characters" data-validation="length alphanumeric" 
             data-validation-length="3-12" 
             data-validation-error-msg="The name has to be an alphanumeric value between 3-12 characters">
      </p>
      <p>
            <b>Email-id</b>
            <input type=text name="userEmailid" placeholder="hello@example.com" data-validation="email">
      </p>
      <p>
            <b>Password</b>
            <input type="password" name="pass_confirmation" placeholder="atleast 8 alpha-numeric characters" 
            data-validation="strength" data-validation-strength="2" data-validation-length="min8">
      </p>
      <p>
            <b>Retype-Password</b>
            <input type="password" name="pass" placeholder="Same as password" data-validation="confirmation" >  
      </p>
      <p>
            <b>Profile Picture</b>
            <input type="file" name="fileToUpload" placeholder="Upload Image" 
            data-validation="mime size" data-validation-allowing="jpg, png" data-validation-max-size="1024kb">
      </p>
      <input type="submit" value="Submit" name="submit"> &nbsp
      <input type=reset>
</form>
<script type="text/javascript"> $.validate({
    modules : 'security,file',onModulesLoaded : function() {
    var optionalConfig = {
      fontSize: '12pt',
      padding: '4px',
      bad : 'Weak Password :( ',
      weak : 'Weak Password :( ',
      good : 'Good Password :) ',
      strong : 'Strong Password :D '
    };

    $('input[name="pass_confirmation"]').displayPasswordStrength(optionalConfig);
  }
  });
</script>
<?php include'footer.php'; ?>