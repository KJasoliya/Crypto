<?php include'header.php'; ?>
<!-- Main -->
        <header class="major">
            <h2>Ciphers & Algorithms</h2>
            <p>VIGENERE CIPHER</p>
        </header>
        <div class="container">
            <div class="row">
                <div class="4u">
                    <section>
                        <h3>Ciphers</h3>
                        <ul class="alt">
                            <?php echo getCipherList(); ?>
                        </ul>
                    </section>
                </div>
                <div class="8u skel-cell-important">
                    <section>
                        <form action="results.php" method="post">
                            <textarea name="VigenerePlaintext" placeholder="Enter the plaintext here to encrypt it (Alphabets Only) " value=""></textarea>
                            <b>OR &nbsp</b><input type=file name="CipherFile" value="Upload File">
                            <br><br>
                            <input type="text" name="VigenereKey" placeholder="Enter key (Alphabets Only) " >
                            <br>
                            <input type="hidden" name="cipherName" value="VIGENERE CIPHER">
                            <input type=submit>
                            <input type=reset>
                        </form>
                    </section>
                </div>
            </div>
        </div>
<?php include'footer.php'; ?>