<?php include'header.php'; ?>
<!-- Banner -->
    <section id="banner">
        <div class="inner">
            <h2>Cypto site</h2>
            <h4>
                This website contains source code & demo of various Ciphers & Algorithms<br>
                Checkout The Demo Section<b><a href="ciphers.php"> here</a></b><br>
                Free Sign Up to record your history and download Source Codes in php
            </h4>
            <ul class="actions">
                <li><a href="signup.php" class="button big special">Sign Up</a></li>
                <li><a href="ciphers.php" class="button big alt">Learn More</a></li>
            </ul>
            <p></p>
        </div>
    </section>
<?php include'footer.php'; ?>
