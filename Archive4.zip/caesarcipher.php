<?php include'header.php'; ?>
<!-- Main -->
        <header class="major">
            <h2>Ciphers & Algorithms</h2>
            <p>CAESAR CIPHER</p>
        </header>
        <div class="container">
            <div class="row">
                <div class="4u">
                    <section>
                        <h3>Ciphers</h3>
                        <ul class="alt">
                            <?php echo getCipherList(); ?>
                        </ul>
                    </section>
                </div>
                <div class="8u skel-cell-important">
                    <section>
                        <form action="results.php" method="post">
                            <textarea name="caesarPlaintext" placeholder="Enter the plaintext here to encrypt it" value=""></textarea>
                            <b>OR &nbsp</b><input type=file name="CipherFile" value="Upload File">
                            <br><br>
                            <input type="text" name="caesarKey" placeholder="Enter key in number (0-25)" >
                            <br>
                            <input type="hidden" name="cipherName" value="CAESAR CIPHER">
                            <input type=submit>
                            <input type=reset>
                        </form>
                    </section>
                </div>
            </div>
        </div>
<?php include'footer.php'; ?>