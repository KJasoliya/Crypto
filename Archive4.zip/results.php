<?php include'header.php'; ?>
<!-- Main -->
        <header class="major">
            <h2>Ciphers & Algorithms</h2>
            <p><?php echo $_POST["cipherName"] ?></p>
        </header>
        <div class="container">
            <div class="row">
                <div class="4u">
                    <section>
                        <h3>Ciphers</h3>
                        <ul class="alt">
                            <?php echo getCipherList(); ?>
                        </ul>
                    </section>
                </div>
                <div class="8u skel-cell-important">
                    <section>
                        <?php 
                            if($_POST["cipherName"]=='CAESAR CIPHER'){
                                echo "<h3>Encrypted Text : &nbsp</h3>";
                                echo "<blockquote><b>".caesar($_POST["caesarPlaintext"],$_POST["caesarKey"])."</b></blockquote>";
                            }
                            else if ($_POST["cipherName"]=='VIGENERE CIPHER') {
                                echo "<h3>Encrypted Text : &nbsp</h3>";
                                echo "<blockquote><b>".VigenereCipher($_POST["VigenerePlaintext"],$_POST["VigenereKey"])."</b></blockquote>";
                            }
                        ?>
                    </section>
                </div>
            </div>
        </div>      
<?php include'footer.php'; ?>